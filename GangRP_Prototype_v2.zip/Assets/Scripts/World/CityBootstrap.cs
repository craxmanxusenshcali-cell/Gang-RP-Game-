using UnityEngine;

public class CityBootstrap : MonoBehaviour
{
    public int citySize = 7;
    public float blockSize = 22f;
    public float roadWidth = 7f;

    void Start()
    {
        GenerateGround();
        GenerateCity();
        CreatePlayer();
        CreateCar();
        CreateLighting();
        gameObject.AddComponent<BootstrapExtras>();
    }

    void GenerateGround()
    {
        GameObject g = GameObject.CreatePrimitive(PrimitiveType.Cube);
        g.name = "CityGround";
        g.transform.position = Vector3.zero;
        g.transform.localScale = new Vector3(citySize * blockSize * 1.2f, 0.2f, citySize * blockSize * 1.2f);
    }

    void GenerateCity()
    {
        float half = citySize / 2f;
        for (int x = 0; x < citySize; x++)
        {
            for (int z = 0; z < citySize; z++)
            {
                float px = (x - half) * blockSize;
                float pz = (z - half) * blockSize;

                CreateBuilding(new Vector3(px + 4f, 2.5f, pz + 4f), new Vector3(7f, 5f, 7f));
                CreateBuilding(new Vector3(px - 4f, 4f, pz - 3f), new Vector3(6f, 8f, 8f));

                if ((x + z) % 3 == 0)
                    CreateBuilding(new Vector3(px + 2f, 7f, pz - 5f), new Vector3(5f, 14f, 5f));
            }
        }

        // Roads
        for (int i = 0; i < citySize; i++)
        {
            float p = (i - half) * blockSize;

            CreateRoad(new Vector3(p, 0.12f, 0), new Vector3(roadWidth, 0.05f, citySize * blockSize));
            CreateRoad(new Vector3(0, 0.13f, p), new Vector3(citySize * blockSize, 0.05f, roadWidth));
        }
    }

    void CreateRoad(Vector3 pos, Vector3 scale)
    {
        GameObject r = GameObject.CreatePrimitive(PrimitiveType.Cube);
        r.name = "Road";
        r.transform.position = pos;
        r.transform.localScale = scale;
    }

    void CreateBuilding(Vector3 pos, Vector3 scale)
    {
        GameObject b = GameObject.CreatePrimitive(PrimitiveType.Cube);
        b.name = "Building";
        b.transform.position = pos;
        b.transform.localScale = scale;
    }

    void CreatePlayer()
    {
        GameObject p = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        p.name = "Player";
        p.transform.position = new Vector3(0, 1.2f, -8f);

        CharacterController cc = p.AddComponent<CharacterController>();
        cc.height = 2f;
        cc.radius = 0.45f;

        PlayerController controller = p.AddComponent<PlayerController>();

        p.AddComponent<PlayerWallet>();

        GameObject cam = new GameObject("PlayerCamera");
        Camera c = cam.AddComponent<Camera>();
        cam.AddComponent<SimpleFollowCamera>().target = p.transform;
        controller.cameraTransform = cam.transform;
        cam.transform.position = p.transform.position + new Vector3(0, 6, -8);
        cam.transform.LookAt(p.transform);
    }

    void CreateCar()
    {
        GameObject car = GameObject.CreatePrimitive(PrimitiveType.Cube);
        car.name = "PlayerCar";
        car.transform.position = new Vector3(0, 0.8f, 8f);
        car.transform.localScale = new Vector3(2.2f, 0.8f, 4f);
        car.AddComponent<CarController>();

        for (int i = 0; i < 4; i++)
        {
            GameObject wheel = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            wheel.transform.SetParent(car.transform);
            wheel.transform.localScale = new Vector3(0.65f, 0.35f, 0.65f);
            wheel.transform.rotation = Quaternion.Euler(90, 0, 0);
            float sx = (i < 2) ? -1.15f : 1.15f;
            float sz = (i % 2 == 0) ? -1.3f : 1.3f;
            wheel.transform.localPosition = new Vector3(sx, -0.35f, sz);
        }
    }

    void CreateLighting()
    {
        GameObject lightObj = new GameObject("Sun");
        Light light = lightObj.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.1f;
        lightObj.transform.rotation = Quaternion.Euler(50, -30, 0);
    }
}

