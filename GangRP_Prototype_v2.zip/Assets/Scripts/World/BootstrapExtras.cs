using UnityEngine;

public class BootstrapExtras : MonoBehaviour
{
    void Start()
    {
        GameObject ui = new GameObject("MobileUI");
        ui.AddComponent<MobileUIBuilder>();

        GameObject game = new GameObject("GameManager");
        game.AddComponent<GameManager>();

        GameObject gang = new GameObject("GangManager");
        gang.AddComponent<GangManager>();

        GameObject missions = new GameObject("MissionManager");
        missions.AddComponent<MissionManager>();

        GameObject police = new GameObject("PoliceManager");
        police.AddComponent<PoliceManager>();
    }
}
