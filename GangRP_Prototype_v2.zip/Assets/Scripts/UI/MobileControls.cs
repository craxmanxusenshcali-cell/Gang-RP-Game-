using UnityEngine;
using UnityEngine.EventSystems;

public class MobileMoveButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    public PlayerController player;
    public Vector2 direction;

    public void OnPointerDown(PointerEventData eventData)
    {
        if (player) player.SetMobileInput(direction);
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        if (player) player.StopMobileInput();
    }
}

public class MobileCarButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    public CarController car;
    public bool steering;
    public float value;

    public void OnPointerDown(PointerEventData eventData)
    {
        if (!car) return;
        if (steering) car.SetSteering(value);
        else car.SetThrottle(value);
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        if (!car) return;
        if (steering) car.StopSteering();
        else car.StopThrottle();
    }
}
