using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class MobileUIBuilder : MonoBehaviour
{
    void Start()
    {
        if (!FindFirstObjectByType<EventSystem>())
        {
            GameObject e = new GameObject("EventSystem");
            e.AddComponent<EventSystem>();
            e.AddComponent<StandaloneInputModule>();
        }

        Canvas canvas = new GameObject("MobileCanvas").AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.gameObject.AddComponent<CanvasScaler>().uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        canvas.gameObject.AddComponent<GraphicRaycaster>();

        PlayerController player = FindFirstObjectByType<PlayerController>();
        CarController car = FindFirstObjectByType<CarController>();

        CreateButton(canvas.transform, "UP", new Vector2(-120, -90), new Vector2(0,1), player, null, false);
        CreateButton(canvas.transform, "DOWN", new Vector2(-120, -210), new Vector2(0,-1), player, null, false);
        CreateButton(canvas.transform, "LEFT", new Vector2(-240, -150), new Vector2(-1,0), player, null, false);
        CreateButton(canvas.transform, "RIGHT", new Vector2(0, -150), new Vector2(1,0), player, null, false);

        CreateButton(canvas.transform, "GAS", new Vector2(230, -90), Vector2.zero, null, car, false);
        CreateButton(canvas.transform, "BRAKE", new Vector2(230, -210), Vector2.zero, null, car, true);
        CreateButton(canvas.transform, "TURN L", new Vector2(100, -150), Vector2.zero, null, car, true);
        CreateButton(canvas.transform, "TURN R", new Vector2(360, -150), Vector2.zero, null, car, true);
    }

    void CreateButton(Transform parent, string label, Vector2 pos, Vector2 playerDir,
        PlayerController player, CarController car, bool carMode)
    {
        GameObject go = new GameObject(label);
        go.transform.SetParent(parent);
        RectTransform rt = go.AddComponent<RectTransform>();
        rt.sizeDelta = new Vector2(100,100);
        rt.anchoredPosition = pos;

        Image img = go.AddComponent<Image>();
        img.raycastTarget = true;

        Text text = new GameObject("Text").AddComponent<Text>();
        text.transform.SetParent(go.transform);
        text.text = label;
        text.alignment = TextAnchor.MiddleCenter;
        text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        text.color = Color.white;
        RectTransform tr = text.rectTransform;
        tr.anchorMin = Vector2.zero;
        tr.anchorMax = Vector2.one;
        tr.offsetMin = Vector2.zero;
        tr.offsetMax = Vector2.zero;

        if (!carMode)
        {
            MobileMoveButton b = go.AddComponent<MobileMoveButton>();
            b.player = player;
            b.direction = playerDir;
        }
        else
        {
            MobileCarButton b = go.AddComponent<MobileCarButton>();
            b.car = car;
            if (label == "TURN L") { b.steering = true; b.value = -1; }
            else if (label == "TURN R") { b.steering = true; b.value = 1; }
            else if (label == "GAS") { b.steering = false; b.value = 1; }
            else { b.steering = false; b.value = -1; }
        }
    }
}
