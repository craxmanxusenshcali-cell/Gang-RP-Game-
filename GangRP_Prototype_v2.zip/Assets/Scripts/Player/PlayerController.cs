using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float rotationSpeed = 12f;
    public CharacterController controller;
    public Transform cameraTransform;

    [HideInInspector] public Vector2 mobileInput;

    void Awake()
    {
        if (controller == null) controller = GetComponent<CharacterController>();
    }

    void Update()
    {
        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");

        if (mobileInput.sqrMagnitude > 0.01f)
        {
            x = mobileInput.x;
            z = mobileInput.y;
        }

        Vector3 input = new Vector3(x, 0, z);
        if (input.magnitude > 1) input.Normalize();

        Vector3 forward = cameraTransform ? Vector3.Scale(cameraTransform.forward, new Vector3(1,0,1)).normalized : Vector3.forward;
        Vector3 right = cameraTransform ? cameraTransform.right : Vector3.right;
        Vector3 dir = (forward * input.z + right * input.x).normalized;

        if (dir.sqrMagnitude > 0.01f)
        {
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(dir), rotationSpeed * Time.deltaTime);
        }

        controller.SimpleMove(dir * moveSpeed);
    }

    public void SetMobileInput(Vector2 value) { mobileInput = value; }
    public void StopMobileInput() { mobileInput = Vector2.zero; }
}
