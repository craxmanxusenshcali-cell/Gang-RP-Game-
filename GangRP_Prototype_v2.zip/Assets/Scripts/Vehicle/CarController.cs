using UnityEngine;

public class CarController : MonoBehaviour
{
    public float speed = 12f;
    public float turnSpeed = 70f;
    [HideInInspector] public float throttle;
    [HideInInspector] public float steering;

    void Update()
    {
        float t = Mathf.Abs(throttle) > 0.01f ? throttle : Input.GetAxis("Vertical");
        float s = Mathf.Abs(steering) > 0.01f ? steering : Input.GetAxis("Horizontal");

        transform.Translate(Vector3.forward * t * speed * Time.deltaTime);
        transform.Rotate(Vector3.up, s * turnSpeed * Time.deltaTime * Mathf.Clamp01(Mathf.Abs(t) + 0.2f));
    }

    public void SetThrottle(float value) { throttle = value; }
    public void SetSteering(float value) { steering = value; }
    public void StopThrottle() { throttle = 0; }
    public void StopSteering() { steering = 0; }
}
