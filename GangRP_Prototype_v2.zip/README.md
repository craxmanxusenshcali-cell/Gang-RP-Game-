# Gang RP Prototype v2

Unity 2022.3 LTS+ starter prototype.

Included:
- Procedural city generator (roads, buildings, lights)
- Player character controller
- Simple drivable car
- Mobile touch buttons
- Gang, cash, missions, wanted system
- Simple HUD

Setup:
1. Create a Unity 3D project.
2. Copy this Assets folder into the project.
3. Open an empty scene named Main.
4. Create an empty GameObject called Bootstrap and add `CityBootstrap`.
5. Press Play. The city, player, car, camera and mobile controls are generated.
6. For Android, switch Build Settings to Android.

Note: The buildings, player and car are intentionally simple Unity primitives so the prototype has no external asset dependencies. They can later be replaced by proper 3D models.
